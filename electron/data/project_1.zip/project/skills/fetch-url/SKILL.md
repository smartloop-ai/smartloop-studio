---
name: fetch-url
description: Use when the user requests to find information from a URL — extracts data from the provided URL and returns it.
tools: [fetch]
---

when user requests information from an url use fetch tool extract information from the URL